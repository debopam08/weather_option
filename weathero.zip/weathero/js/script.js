let api_key = '9290e4e54c2f02775d258dee8e6d46eb';

//Using Jquery

$( "#btnClick" ).on( "click", function() {
    var city_val = $('.searchbar').val();
    
    $.getJSON("https://api.openweathermap.org/data/2.5/weather?q="+city_val+"&units=metric&appid="+api_key, function(data) {
        
        console.log(data);   

        const cityname = data.name;
        const main_temp = data.main;
        const windsp    = data.wind;
        const sun       = data.sys;
        const weather   = data.weather[0];

        $('.weather').removeClass('loading');

        $(".city").text('Weather in '+cityname);
        $(".icon").attr('src',"https://openweathermap.org/img/wn/" + weather.icon + ".png");
        $(".description").text(weather.description);
        $(".temp").text(main_temp.temp + "°C");
        $(".humidity").text("Humidity: " + main_temp.humidity + "%");
        $(".wind").text("Wind speed: " + windsp.speed + " km/h");
        $(".feels_like").text("Feels Like: " + main_temp.feels_like + "°C");
        $(".temp_max").text("Max Temperature: " + main_temp.temp_max + "°C");
        $(".temp_min").text("Min Temperature: " + main_temp.temp_min + "°C");
    });
});

$( ".searchbar" ).on( "keyup", function(e) {
    if(e.key == "Enter"){
        $("#btnClick").trigger("click");
    }
});



//Using javascript

document.getElementById("btn_Click").addEventListener("click", weather_fetch);

function weather_fetch(){
    let city_value = document.getElementsByClassName('search_bar')[0].value; 
    let api_url = "https://api.openweathermap.org/data/2.5/weather?q="+city_value+"&units=metric&appid="+api_key;
    
    fetch_weatherData = fetch(api_url)
    .then(response => {
        // Check if the request was successful
        if (!response.ok) {
        throw new Error('Network issue & response not received');
        }
        // Parse the response as JSON
        return response.json();
    })
    .then(data => {
        // Handle the JSON data
        console.log(data);

        const _cityname = data.name;
        const _main_temp = data.main;
        const _windsp    = data.wind;
        const _sun       = data.sys;
        const _weather   = data.weather[0];

        $('.weather').removeClass('_loading');

        document.querySelector('._city').innerHTML = 'Weather in '+_cityname;
        document.querySelector("._icon").src = "https://openweathermap.org/img/wn/" + _weather.icon + ".png";
        document.querySelector("._description").innerHTML = _weather.description;
        document.querySelector("._temp").innerHTML = _main_temp.temp + "°C";
        document.querySelector("._humidity").innerHTML = "Humidity: " + _main_temp.humidity + "%";
        document.querySelector("._wind").innerHTML = "Wind speed: " + _windsp.speed + " km/h";
        document.querySelector("._feels_like").innerHTML = "Feels Like: " + _main_temp.feels_like + "°C";
        document.querySelector("._temp_max").innerHTML ="Max Temperature: " + _main_temp.temp_max + "°C";
        document.querySelector("._temp_min").innerHTML  ="Min Temperature: " + _main_temp.temp_min + "°C";
    })
    .catch(error => {
        // Handle any errors that occurred during the fetch
        console.error('Fetch error:', error);
    });
}

document.querySelector(".search_bar").addEventListener("keyup", function(event){
    if(event.key == "Enter"){
        weather_fetch();
    }
});
